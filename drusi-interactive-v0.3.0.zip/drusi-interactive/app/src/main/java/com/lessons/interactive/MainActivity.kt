package com.lessons.interactive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DrusiApp(applicationContext) }
    }
}

@Composable
fun DrusiApp(context: android.content.Context) {
    val repo = remember { LessonRepository(context) }
    var lessons by remember { mutableStateOf(repo.loadLessons()) }
    var selected by remember { mutableStateOf<Lesson?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    MaterialTheme {
        when {
            showSettings -> SettingsScreen(repo) { showSettings = false }
            selected != null -> LessonScreen(repo, selected!!, onBack = { selected = null })
            else -> HomeScreen(lessons, repo, { selected = it }, { showSettings = true })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(lessons: List<Lesson>, repo: LessonRepository, open: (Lesson) -> Unit, settings: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("دروسي التفاعلية") }, actions = { TextButton(onClick = settings) { Text("الإعدادات") } }) }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("English B1", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text("دروس منظمة مع تمارين وتعلم تفاعلي") }
            items(lessons) { lesson ->
                val progress = repo.progress(lesson.id, lesson.sections.size)
                Card(Modifier.fillMaxWidth().clickable { open(lesson) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(lesson.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        if (lesson.arabicTitle.isNotBlank()) Text(lesson.arabicTitle)
                        Text("المستوى: ${lesson.level}  •  ${lesson.sections.size} أقسام")
                        LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth().padding(top = 10.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonScreen(repo: LessonRepository, lesson: Lesson, onBack: () -> Unit) {
    var index by remember { mutableIntStateOf(repo.position(lesson.id).coerceIn(0, lesson.sections.lastIndex.coerceAtLeast(0))) }
    var answer by remember { mutableStateOf(repo.answer(lesson.id, index)) }
    var result by remember { mutableStateOf(repo.result(lesson.id, index)) }
    var chat by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text(lesson.title) }, navigationIcon = { TextButton(onClick = onBack) { Text("رجوع") } }, actions = { TextButton(onClick = { chat = true }) { Text("المعلم") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("القسم ${index + 1} من ${lesson.sections.size}", fontWeight = FontWeight.Bold)
            LinearProgressIndicator(progress = { (index + 1f) / lesson.sections.size }, Modifier.fillMaxWidth().padding(vertical = 10.dp))
            Text(lesson.sections[index].title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(lesson.sections[index].body, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(18.dp))
            if (looksInteractive(lesson.sections[index].body)) {
                OutlinedTextField(value = answer, onValueChange = { answer = it; repo.saveAnswer(lesson.id, index, it) }, modifier = Modifier.fillMaxWidth(), label = { Text("إجابتك") }, minLines = 3)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { result = "Unsupported"; repo.saveResult(lesson.id,index,result) }) { Text("إجابة حرة") }
                    OutlinedButton(onClick = { result = "Pending"; repo.saveResult(lesson.id,index,result) }) { Text("اطلب تقييم المعلم") }
                }
                if (result.isNotBlank()) Text("الحالة: $result", Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(enabled = index > 0, onClick = { index--; answer = repo.answer(lesson.id,index); result = repo.result(lesson.id,index); repo.savePosition(lesson.id,index) }) { Text("السابق") }
                Button(enabled = index < lesson.sections.lastIndex, onClick = { index++; answer = repo.answer(lesson.id,index); result = repo.result(lesson.id,index); repo.savePosition(lesson.id,index) }) { Text("التالي") }
            }
        }
    }
    if (chat) TutorDialog(repo, lesson, lesson.sections[index]) { chat = false }
}

private fun looksInteractive(text: String): Boolean = listOf("اختر", "Choose", "Fill", "Complete", "أكمل", "صح", "خطأ", "السؤال", "Question", "رتب", "Reorder").any { text.contains(it, ignoreCase = true) }

@Composable
fun TutorDialog(repo: LessonRepository, lesson: Lesson, section: Section, close: () -> Unit) {
    val scope = rememberCoroutineScope(); var input by remember { mutableStateOf("") }; var reply by remember { mutableStateOf("اكتب سؤالك عن هذا القسم وسأحاول مساعدتك.") }; var busy by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = close, title = { Text("المعلم الذكي") }, text = {
        Column { Text(reply); Spacer(Modifier.height(10.dp)); OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), label = { Text("رسالتك") }) }
    }, confirmButton = { Button(enabled = !busy && input.isNotBlank(), onClick = { busy = true; scope.launch { reply = repo.askTutor(lesson, section, input); busy = false } }) { Text(if (busy) "جارٍ..." else "إرسال") } }, dismissButton = { TextButton(onClick = close) { Text("إغلاق") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(repo: LessonRepository, close: () -> Unit) {
    var provider by remember { mutableStateOf(repo.provider()) }; var model by remember { mutableStateOf(repo.model()) }; var key by remember { mutableStateOf(repo.apiKey()) }; var saved by remember { mutableStateOf(false) }
    Scaffold(topBar = { TopAppBar(title = { Text("الإعدادات") }, navigationIcon = { TextButton(onClick = close) { Text("رجوع") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("المعلم الذكي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            OutlinedTextField(provider, { provider = it }, Modifier.fillMaxWidth(), label = { Text("المزود: gemini أو openai") })
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("اسم النموذج") })
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API Key") })
            Button(onClick = { repo.saveSettings(provider, model, key); saved = true }, Modifier.fillMaxWidth()) { Text("حفظ الإعدادات") }
            if (saved) Text("تم الحفظ محليًا بشكل مشفر.")
        }
    }
}
