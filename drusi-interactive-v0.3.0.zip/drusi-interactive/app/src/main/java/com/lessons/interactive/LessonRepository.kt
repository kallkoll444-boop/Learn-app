package com.lessons.interactive

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.util.Locale

data class Section(val title: String, val body: String)
data class Lesson(val id: String, val number: Int, val title: String, val arabicTitle: String, val level: String, val sections: List<Section>)

class LessonRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("drusi", Context.MODE_PRIVATE)
    private val client = OkHttpClient()

    fun loadLessons(): List<Lesson> = context.assets.list("lessons").orEmpty().mapNotNull { name ->
        runCatching { parseLesson(name, context.assets.open("lessons/$name").bufferedReader().use { it.readText() }) }.getOrNull()
    }.sortedBy { it.number }

    private fun parseLesson(name: String, text: String): Lesson {
        val lines = text.replace("\r", "").lines(); val first = lines.firstOrNull().orEmpty(); val number = Regex("Lesson\\s+(\\d+)", RegexOption.IGNORE_CASE).find(first)?.groupValues?.get(1)?.toIntOrNull() ?: extractNumber(name)
        val title = lines.drop(1).firstOrNull { it.isNotBlank() }.orEmpty(); val arabic = lines.drop(2).firstOrNull { it.isNotBlank() && !it.startsWith("Level:") }.orEmpty(); val level = lines.firstOrNull { it.startsWith("Level:") }?.substringAfter(":")?.trim() ?: "B1"
        val starts = lines.mapIndexedNotNull { i,l -> if (Regex("^\\d+\\.\\s+.+").matches(l.trim())) i to l.trim() else null }
        val sections = if (starts.isEmpty()) listOf(Section(title, text)) else starts.mapIndexed { idx, pair -> val end = if (idx+1 < starts.size) starts[idx+1].first else lines.size; val heading = pair.second.substringAfter(". "); Section(heading, lines.subList(pair.first+1,end).joinToString("\n").trim()) }
        return Lesson("lesson_$number", number, title, arabic, level, sections)
    }
    private fun extractNumber(s:String)=Regex("\\d+").find(s)?.value?.toIntOrNull() ?: 999
    fun position(id:String)=prefs.getInt("pos_$id",0); fun savePosition(id:String,p:Int)=prefs.edit().putInt("pos_$id",p).apply()
    fun answer(id:String,i:Int)=prefs.getString("ans_${id}_$i","").orEmpty(); fun result(id:String,i:Int)=prefs.getString("res_${id}_$i","").orEmpty()
    fun saveAnswer(id:String,i:Int,v:String)=prefs.edit().putString("ans_${id}_$i",v).apply(); fun saveResult(id:String,i:Int,v:String)=prefs.edit().putString("res_${id}_$i",v).apply()
    fun progress(id:String,total:Int):Float { if(total<=0)return 0f; return ((position(id)+1).coerceAtMost(total)).toFloat()/total }
    fun provider()=prefs.getString("provider","gemini").orEmpty(); fun model()=prefs.getString("model","gemini-2.5-flash").orEmpty(); fun apiKey()=decrypt(prefs.getString("api","").orEmpty())
    fun saveSettings(p:String,m:String,k:String){prefs.edit().putString("provider",p.trim().lowercase(Locale.US)).putString("model",m.trim()).putString("api",encrypt(k)).apply()}

    suspend fun askTutor(lesson:Lesson, section:Section, question:String):String = withContext(Dispatchers.IO) {
        val key=apiKey(); if(key.isBlank()) return@withContext "أضف API Key من الإعدادات أولًا."
        val prompt="أنت معلم إنجليزي B1. اشرح للطالب بالعربية مع أمثلة إنجليزية بسيطة. الدرس: ${lesson.title}. القسم: ${section.title}. محتوى القسم:\n${section.body}\n\nرسالة الطالب: $question"
        runCatching { if(provider()=="openai") openAi(key,prompt) else gemini(key,prompt) }.getOrElse { "تعذر الاتصال بالمعلم: ${it.message ?: "خطأ غير معروف"}" }
    }
    private fun gemini(key:String,prompt:String):String { val json=JSONObject().put("contents",JSONArray().put(JSONObject().put("parts",JSONArray().put(JSONObject().put("text",prompt))))); val req=Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/${model()}:generateContent").addHeader("x-goog-api-key",key).post(json.toString().toRequestBody("application/json".toMediaType())).build(); client.newCall(req).execute().use { r -> val b=r.body?.string().orEmpty(); if(!r.isSuccessful) error("HTTP ${r.code}"); return JSONObject(b).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text") } }
    private fun openAi(key:String,prompt:String):String { val json=JSONObject().put("model",model()).put("messages",JSONArray().put(JSONObject().put("role","user").put("content",prompt))); val req=Request.Builder().url("https://api.openai.com/v1/chat/completions").addHeader("Authorization","Bearer $key").post(json.toString().toRequestBody("application/json".toMediaType())).build(); client.newCall(req).execute().use { r -> val b=r.body?.string().orEmpty(); if(!r.isSuccessful) error("HTTP ${r.code}"); return JSONObject(b).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content") } }

    private fun key():SecretKey { val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}; val alias="drusi_key"; (ks.getKey(alias,null) as? SecretKey)?.let{return it}; val kg=KeyGenerator.getInstance("AES","AndroidKeyStore"); kg.init(256); return kg.generateKey() }
    private fun encrypt(s:String):String { if(s.isEmpty())return ""; val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,key()); val raw=c.iv+c.doFinal(s.toByteArray(Charsets.UTF_8)); return Base64.encodeToString(raw,Base64.NO_WRAP) }
    private fun decrypt(s:String):String { if(s.isEmpty())return ""; return runCatching { val raw=Base64.decode(s,Base64.NO_WRAP); val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,raw.copyOfRange(0,12))); String(c.doFinal(raw.copyOfRange(12,raw.size)),Charsets.UTF_8) }.getOrDefault("") }
}
